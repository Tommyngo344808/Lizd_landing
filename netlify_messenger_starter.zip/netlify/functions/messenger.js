// netlify/functions/messenger.js
// Webhook Facebook Messenger (verify + nhận sự kiện + trả lời mẫu)
// Yêu cầu đặt ENV: VERIFY_TOKEN, PAGE_ACCESS_TOKEN

const VERIFY_TOKEN = process.env.VERIFY_TOKEN;
const PAGE_ACCESS_TOKEN = process.env.PAGE_ACCESS_TOKEN;

// Helper gửi tin nhắn bằng Send API (Node 18+ có fetch global)
async function sendText(psid, text) {
  const url = `https://graph.facebook.com/v20.0/me/messages?access_token=${PAGE_ACCESS_TOKEN}`;
  const body = {
    recipient: { id: psid },
    message: { text }
  };
  const resp = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  if (!resp.ok) {
    const t = await resp.text();
    console.error("Send API error:", resp.status, t);
  }
}

exports.handler = async (event) => {
  // 1) Verify webhook (Facebook gọi GET lần đầu)
  if (event.httpMethod === "GET") {
    const p = event.queryStringParameters || {};
    if (p["hub.mode"] === "subscribe" && p["hub.verify_token"] === VERIFY_TOKEN) {
      return { statusCode: 200, body: p["hub.challenge"] };
    }
    return { statusCode: 403, body: "verify token mismatch" };
  }

  // 2) Nhận sự kiện (Facebook gọi POST khi có tin nhắn)
  if (event.httpMethod === "POST") {
    try {
      const body = JSON.parse(event.body || "{}");
      const entries = body.entry || [];
      for (const entry of entries) {
        const messagingEvents = entry.messaging || [];
        for (const msg of messagingEvents) {
          const sender = msg.sender && msg.sender.id;
          const text = msg.message && msg.message.text;
          if (sender && text) {
            // Auto-reply mẫu
            await sendText(sender, "Xin chào 👋 Bot đã nhận: " + text);
          }
        }
      }
    } catch (e) {
      console.error("Webhook error:", e);
      // vẫn trả 200 để FB không retry liên tục
    }
    return { statusCode: 200, body: "EVENT_RECEIVED" };
  }

  return { statusCode: 405, body: "Method Not Allowed" };
};
